const express = require("express");
const dotenv = require("dotenv");
const fs = require("fs");
const path = require("path");

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;

const apiPath = path.join(__dirname, "api");
fs.readdirSync(apiPath).forEach((file) => {
    if (file.endsWith(".js")) {
        const route = require(`./api/${file}`);
        app.use("/api/kappi", route);
    }
});

app.listen(PORT, () => {
    console.log(`
--------------------
+ Api Sunucusu Aktif, Kullanabileceginiz Api Linkleri Assagida Listelenmistir! 

Developer By Kappi7581

(Herhangi Bir Api'ye Ctrl + Mouse Sol Clik Basarak Erişebilirsiniz)
--------------------
> http://localhost:${PORT}/api/kappi/adres?tc=11111111110&auth=t.me/Kappi7581Dev
> http://localhost:${PORT}/api/kappi/adres2015?tc=11404305356&auth=t.me/Kappi7581Dev
> http://localhost:${PORT}/api/kappi/adsoyad?ad=ROKET&soyad=ATAR&auth=t.me/Kappi7581Dev
> http://localhost:${PORT}/api/kappi/adsoyadpro?ad=ROKET&soyad=ATAR&il=BURSA&ilce=OSMANGAZİ&auth=t.me/Kappi7581Dev
> http://localhost:${PORT}/api/kappi/aile?tc=27727166918&auth=t.me/Kappi7581Dev
> http://localhost:${PORT}/api/kappi/ailepro?tc=27727166918&auth=t.me/Kappi7581Dev
> http://localhost:${PORT}/api/kappi/akp?tc=48364813782&auth=t.me/Kappi7581Dev
> http://localhost:${PORT}/api/kappi/bin?bin=548793&auth=t.me/Kappi7581Dev
> http://localhost:${PORT}/api/kappi/bolgetapu?il=ADANA&ilce=ALADAĞ&mahalle=AKPINAR&auth=t.me/Kappi7581Dev
> http://localhost:${PORT}/api/kappi/decend?yazi=kappi&donusumturu=base64_encode&auth=t.me/Kappi7581Dev
> http://localhost:${PORT}/api/kappi/dns?url=trendyol.com&auth=t.me/Kappi7581Dev
> http://localhost:${PORT}/api/kappi/facebook?gsm=05375890913&auth=t.me/Kappi7581Dev
> http://localhost:${PORT}/api/kappi/finder?terim=riot&auth=t.me/Kappi7581Dev
> http://localhost:${PORT}/api/kappi/gpt?soru=MERHABA&auth=t.me/Kappi7581Dev
> http://localhost:${PORT}/api/kappi/gsmtc?gsm=5070248311&auth=t.me/Kappi7581Dev
> http://localhost:${PORT}/api/kappi/convert?doviz=BTC&cevirilecekdoviz=USDT&miktar=1&auth=t.me/Kappi7581Dev
> http://localhost:${PORT}/api/kappi/ip?ip=193.42.103.147&auth=t.me/Kappi7581Dev
> http://localhost:${PORT}/api/kappi/istadaparsel?mahalle=ABDİÇELEBİ&ada=2385&parsel=171&auth=t.me/Kappi7581Dev
> http://localhost:${PORT}/api/kappi/istapu?tc=52099059896&auth=t.me/Kappi7581Dev
> http://localhost:${PORT}/api/kappi/istbolgetapu?mahalle=ABDİÇELEBİ&auth=t.me/Kappi7581Dev
> http://localhost:${PORT}/api/kappi/isyeri?tc=11144576054&auth=t.me/Kappi7581Dev
> http://localhost:${PORT}/api/kappi/kocaadaparsel?mahalle=AKSIĞIN&ada=125&parsel=6&auth=t.me/Kappi7581Dev
> http://localhost:${PORT}/api/kappi/kocatapubolge?mahalle=AKSIĞIN&auth=t.me/Kappi7581Dev
> http://localhost:${PORT}/api/kappi/kocatapu?tc=50563620726&auth=t.me/Kappi7581Dev
> http://localhost:${PORT}/api/kappi/mail?email=kappix@gmail.com&auth=t.me/Kappi7581Dev
> http://localhost:${PORT}/api/kappi/okulno?tc=10955162098&auth=t.me/Kappi7581Dev
> http://localhost:${PORT}/api/kappi/operator?gsm=5070248311&auth=t.me/Kappi7581Dev
> http://localhost:${PORT}/api/kappi/kazi?url=https://riotgames.com&auth=t.me/Kappi7581Dev
> http://localhost:${PORT}/api/kappi/screenshot?url=https://t.me/kappix?&auth=t.me/Kappi7581Dev
> http://localhost:${PORT}/api/kappi/sifreolusturucu?uzunluk=10&auth=t.me/Kappi7581Dev
> http://localhost:${PORT}/api/kappi/sulale?tc=11404305356&auth=t.me/Kappi7581Dev
> http://localhost:${PORT}/api/kappi/sulalepro?tc=11404305356&auth=t.me/Kappi7581Dev
> http://localhost:${PORT}/api/kappi/tapu?tc=11404305356&auth=t.me/Kappi7581Dev
> http://localhost:${PORT}/api/kappi/tapuadaparsel?il=ADANA&ilce=ALADAĞ&mahalle=AKPINAR&ada=186&parsel=1&auth=t.me/Kappi7581Dev
> http://localhost:${PORT}/api/kappi/tapubolge?mahalle=ZÜMRÜTOVA&auth=t.me/Kappi7581Dev
> http://localhost:${PORT}/api/kappi/tc?tc=11404305356&auth=t.me/Kappi7581Dev
> http://localhost:${PORT}/api/kappi/tcgsm?tc=11404305356&auth=t.me/Kappi7581Dev
> http://localhost:${PORT}/api/kappi/tcpro?tc=11404305356&auth=t.me/Kappi7581Dev
> http://localhost:${PORT}/api/kappi/vesika?tc=19007791262&auth=t.me/Kappi7581Dev
> http://localhost:${PORT}/api/kappi/yabanci?gsm=07504489985&auth=t.me/Kappi7581Dev`);
});
