const express = require("express");
const axios = require("axios");

const router = express.Router();
const rateLimit = require("express-rate-limit");
const limiter = rateLimit({
    windowMs: 10 * 1000,
    max: 5,
    message: { uyari: "Cok Fazla, İstek Atmaktasiniz!" }
});

router.get("/ip", limiter, async (req, res) => {
    const { ip, auth } = req.query;

    if (auth !== "t.me/Kappi7581Dev") {
        return res.status(401).json({ uyari: "Yetkisiz Erisim!" });
    }

    if (!/^\d{1,3}(\.\d{1,3}){3}$/.test(ip)) {
        return res.status(400).json({ uyari: "Lutfen Gecerli Bir, İp Adresi Giriniz!" });
    }

    try {
        const response = await axios.get(`https://kappi-api.vercel.app/api/ip?ip=${ip}`);
        const data = response.data;

        if (data.status === "fail") {
            return res.status(404).json({ bilgi: "Sonuc Bulunamadi!" });
        }

        return res.json({
            apiSahibi: "Kappi7581",
            apiTelegramGrubu: "t.me/Kappi7581Dev",
            veri: {
                IP: data.query,
                Ülke: data.country,
                "Ülke Kodu": data.countryCode,
                Bölge: data.regionName,
                "Bölge Kodu": data.region,
                Şehir: data.city,
                "Posta Kodu": data.zip,
                Enlem: data.lat,
                Boylam: data.lon,
                "Zaman Dilimi": data.timezone,
                ISP: data.isp,
                Organizasyon: data.org,
                "AS Numarası/Adı": data.as,
                Harita: `https://www.google.com/maps?q=${data.lat},${data.lon}`,
                Developer: "Kappi7581"
            }
        });

    } catch (error) {
        console.error("Sunucu Hatasi:", error.message);
        return res.status(500).json({ hata: "Sunucu Hatasi Olustu!" });
    }
});

module.exports = router;